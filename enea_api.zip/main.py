
from fastapi import FastAPI, Query
from typing import List
import random

app = FastAPI()

# Simulatore di analisi Amazon (mock, senza scraping reale)
@app.get("/analizza_keyword")
def analizza_keyword(keyword: str):
    categorie = ["Coloring Books for Adults", "Activity Books", "Inspirational Coloring"]
    idee = [
        "Libro da colorare in stile cozy con gatti e tè",
        "Frasi motivazionali da colorare con fiori delicati",
        "Animali buffi in scenari rilassanti",
        "Avventure di un personaggio da colorare stile fumetto"
    ]
    return {
        "keyword": keyword,
        "categoria_suggerita": random.choice(categorie),
        "titoli_simili": [
            f"{keyword} vol.1",
            f"{keyword} for adults",
            f"Easy {keyword} Book"
        ],
        "idee_di_contenuto": random.sample(idee, 2)
    }
